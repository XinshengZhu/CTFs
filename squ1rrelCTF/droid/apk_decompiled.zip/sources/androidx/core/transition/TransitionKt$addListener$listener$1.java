package androidx.core.transition;

import android.transition.Transition;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

@Metadata(d1 = {"\u0000\u0019\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005*\u0001\u0000\b\n\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\u0007\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\b\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016J\u0010\u0010\t\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\n"}, d2 = {"androidx/core/transition/TransitionKt$addListener$listener$1", "Landroid/transition/Transition$TransitionListener;", "onTransitionCancel", "", "transition", "Landroid/transition/Transition;", "onTransitionEnd", "onTransitionPause", "onTransitionResume", "onTransitionStart", "core-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 176)
/* compiled from: Transition.kt */
public final class TransitionKt$addListener$listener$1 implements Transition.TransitionListener {
    final /* synthetic */ Function1<Transition, Unit> $onCancel;
    final /* synthetic */ Function1<Transition, Unit> $onEnd;
    final /* synthetic */ Function1<Transition, Unit> $onPause;
    final /* synthetic */ Function1<Transition, Unit> $onResume;
    final /* synthetic */ Function1<Transition, Unit> $onStart;

    public TransitionKt$addListener$listener$1(Function1<? super Transition, Unit> $onEnd2, Function1<? super Transition, Unit> $onResume2, Function1<? super Transition, Unit> $onPause2, Function1<? super Transition, Unit> $onCancel2, Function1<? super Transition, Unit> $onStart2) {
        this.$onEnd = $onEnd2;
        this.$onResume = $onResume2;
        this.$onPause = $onPause2;
        this.$onCancel = $onCancel2;
        this.$onStart = $onStart2;
    }

    public void onTransitionEnd(Transition transition) {
        this.$onEnd.invoke(transition);
    }

    public void onTransitionResume(Transition transition) {
        this.$onResume.invoke(transition);
    }

    public void onTransitionPause(Transition transition) {
        this.$onPause.invoke(transition);
    }

    public void onTransitionCancel(Transition transition) {
        this.$onCancel.invoke(transition);
    }

    public void onTransitionStart(Transition transition) {
        this.$onStart.invoke(transition);
    }
}
